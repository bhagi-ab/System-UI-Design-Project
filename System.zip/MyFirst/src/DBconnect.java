
import com.sun.jdi.connect.spi.Connection;
import com.mysql.jdbc.*;
import java.sql.DriverManager;
import javax.swing.JOptionPane;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author E7440
 */
public class DBconnect {
    static Connection connect(){
    Connection con = null;
    try{
    Class.forName("com.mysql.jdbc.Driver");
    con = (Connection)DriverManager.getConnection("jdbc:mysql://localhost:3308/swptest1?","root","") ;
    JOptionPane.showMessageDialog(null, "Connection Successfull!");
    } catch (Exception e){
        JOptionPane.showMessageDialog(null, "Connection fail!");
    }
    return con;
    }
}
